const Content = ()=>{
    return(
        <h1>Hello, I am Content Component!</h1>
    )
}

export default Content