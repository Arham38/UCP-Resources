const Footer = ()=>{
    return(
        <h1>Hello, I am Footer Component!</h1>
    )
}

export default Footer