const Header = ()=>{
    
    let heading = "ucp";
    const s ={
        color : "red",
        fontSize : "50px",
        backgroundColor: "yellow"
    };

    return(
    <div>
        <h1 style={{color:"blue", fontSize:"80px"}}>Hello, I am {heading} Component!</h1>
        <p style={s}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat, quis!</p>
    </div>
    )
}
export default Header