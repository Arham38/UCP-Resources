import React from 'react'
import { useState } from 'react'
// import Header from './components/Header'
// import Button from './components/Button'
// import Footer from './components/Footer'

import './index.css'

function App() {
    const[count,setCount]=useState(0)
    const increment=()=>{
        setCount(count+1);
    }
    const decrement=()=>{
        setCount(count-1);
    }

  return (
        <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h2>Count: {count}</h2>

      <button
        onClick={increment}
        style={{ marginRight: '10px', padding: '10px' }}
      >
        +
      </button>

      <button
        onClick={decrement}
        style={{ padding: '10px' }}
      >
        -
      </button>
    </div>
  )
}

export default App