import React from 'react'


// // •	Display the website title.
// •	Include a simple navigation menu with the following links:
// o	Home
// o	About
// o	Contact

function Header() {

    const myStyle={
        backgroundColor: "#333", 
  color: "white", 
  padding: "15px",
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center"
     }
    const display={display:'flex',gap:'15px',listStyle:'none'}
  return (
    <header style={myStyle}>
      <h3>LMS</h3>
      <ul style={display}>
        <li><a href="#"  style={{color:'white'}}>Home</a></li>
        <li><a href="#" style={{color:'white'}}>About</a></li>
        <li><a href="#" style={{color:'white'}}>Contact</a></li>
      </ul>
    </header>
  )
}

export default Header
