import React from 'react'
import Header from './components/Header'
import Button from './components/Button'
import Footer from './components/Footer'
import './index.css'

function App() {
  return (
    <div className="app-container">
      <Header />

      <main>
        <h3>Welcome To Our Website</h3>
        <p>
          This is a simple React application demonstrating reusable components.
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam, nobis. Enim vero eveniet non rem? Ducimus corporis expedita voluptate veritatis ad aut architecto debitis quibusdam. Maxime tenetur rem repellat nulla!
          Praesentium vel repellat libero eos, recusandae consequuntur quis at enim modi non, illo voluptates. Nostrum, alias eos veniam eum voluptatibus amet ipsum quo unde nisi asperiores, at ad perspiciatis quia!
          Eos rerum maiores, sapiente architecto ipsa mollitia consectetur esse veritatis optio ipsam quae dolorem facilis ratione aspernatur eveniet doloribus culpa, suscipit fugiat alias dolor eaque quisquam dolorum. Autem, praesentium qui!
          Minus dignissimos pariatur laudantium sed corrupti molestiae inventore voluptas deserunt accusamus ab soluta doloribus sapiente eos corporis possimus vitae assumenda eius nostrum, omnis et! Sapiente dolores ullam suscipit aperiam atque.
          Error voluptatem architecto facilis harum commodi reprehenderit blanditiis, doloribus eveniet ipsa, accusamus veniam eius cumque maiores ullam, molestiae molestias. Quam iusto non quia veritatis, voluptatibus dolores cumque sunt neque recusandae.
          Saepe aut sed consequuntur rerum numquam dolorem nisi autem ad, veritatis vel cupiditate animi eveniet! Ipsam dolorem saepe earum, optio quas sit quam dolorum autem. Vero totam numquam pariatur similique.
          Quaerat deserunt eaque numquam id harum non sequi eos quibusdam quis minus, repellat optio eius debitis dolore placeat tenetur culpa necessitatibus. Molestias atque magnam nostrum quos tempora, impedit ipsam quo.
          Magni dicta modi deleniti error beatae quas, porro commodi soluta nihil delectus similique quo, totam ipsum cum id, voluptate a architecto doloremque! Nisi ducimus fugiat harum dolorem asperiores assumenda voluptate!
          Accusamus nemo inventore fugiat deserunt maiores voluptates nisi nostrum iure quaerat! Hic, molestias amet quos dicta, tenetur sed fuga libero quaerat, voluptate culpa excepturi odit provident fugiat nostrum nobis necessitatibus.
          Minus esse facere possimus dolorem quod. Recusandae iste dolores voluptatibus at tenetur voluptas fuga a inventore consectetur sit provident excepturi ipsam eius culpa dolorem deleniti, nesciunt assumenda quasi nam. Officia!
        </p>

        <Button text="Click Me" />
      </main>

      <Footer />
    </div>
  )
}

export default App