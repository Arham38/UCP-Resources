import api from './api';

export const getCourses = () => api.get('/courses');
export const getCourseById = (id) => api.get(`/courses/${id}`);
export const createCourse = (formData) => api.post('/courses', formData);
export const updateCourse = (id, courseData) => api.put(`/courses/${id}`, courseData);
export const deleteCourse = (id) => api.delete(`/courses/${id}`);

export const getLessons = (courseId) => api.get(`/courses/${courseId}/lessons`);
export const createLesson = (courseId, formData) => api.post(`/courses/${courseId}/lessons`, formData);
export const deleteLesson = (id) => api.delete(`/lessons/${id}`);
