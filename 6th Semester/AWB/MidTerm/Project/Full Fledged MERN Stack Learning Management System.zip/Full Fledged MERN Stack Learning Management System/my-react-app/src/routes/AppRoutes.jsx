import React, { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import ProtectedRoute from '../components/ProtectedRoute';
import RoleRoute from '../components/RoleRoute';
import Loader from '../components/Loader';

// ─── Lazy Imports ─────────────────────────────────────────────────────────────
const Home = lazy(() => import('../pages/Home'));
const About = lazy(() => import('../pages/About'));
const Contact = lazy(() => import('../pages/Contact'));
const Courses = lazy(() => import('../pages/Courses'));
const CourseDetails = lazy(() => import('../pages/CourseDetails'));
const Login = lazy(() => import('../pages/Login'));
const Register = lazy(() => import('../pages/Register'));

const DashboardLayout = lazy(() => import('../pages/dashboard/DashboardLayout'));

const StudentDashboard = lazy(() => import('../pages/dashboard/student/StudentDashboard'));
const MyCourses = lazy(() => import('../pages/dashboard/student/MyCourses'));
const Profile = lazy(() => import('../pages/dashboard/student/Profile'));

const InstructorDashboard = lazy(() => import('../pages/dashboard/instructor/InstructorDashboard'));
const CreateCourse = lazy(() => import('../pages/dashboard/instructor/CreateCourse'));
const InstructorManageCourses = lazy(() => import('../pages/dashboard/instructor/ManageCourses'));
const UploadLesson = lazy(() => import('../pages/dashboard/instructor/UploadLesson'));

const AdminDashboard = lazy(() => import('../pages/dashboard/admin/AdminDashboard'));
const ManageUsers = lazy(() => import('../pages/dashboard/admin/ManageUsers'));
const AdminManageCourses = lazy(() => import('../pages/dashboard/admin/ManageCourses'));
const Analytics = lazy(() => import('../pages/dashboard/admin/Analytics'));

// New feature pages
const QuizPage = lazy(() => import('../pages/QuizPage'));
const ChatPage = lazy(() => import('../pages/ChatPage'));
const LessonPlayer = lazy(() => import('../pages/LessonPlayer'));

// ─── Sidebar Configs ──────────────────────────────────────────────────────────
const STUDENT_SIDEBAR = [
  { path: '/student/dashboard', label: 'Dashboard', icon: 'speedometer2' },
  { path: '/student/courses', label: 'My Courses', icon: 'book' },
  { path: '/student/profile', label: 'Profile', icon: 'person' },
];

const INSTRUCTOR_SIDEBAR = [
  { path: '/instructor/dashboard', label: 'Dashboard', icon: 'speedometer2' },
  { path: '/instructor/create-course', label: 'Create Course', icon: 'plus-circle' },
  { path: '/instructor/courses', label: 'Manage Courses', icon: 'book' },
  { path: '/instructor/upload-lesson', label: 'Upload Lesson', icon: 'cloud-upload' },
];

const ADMIN_SIDEBAR = [
  { path: '/admin/dashboard', label: 'Dashboard', icon: 'speedometer2' },
  { path: '/admin/users', label: 'Manage Users', icon: 'people' },
  { path: '/admin/courses', label: 'Manage Courses', icon: 'book' },
  { path: '/admin/analytics', label: 'Analytics', icon: 'graph-up' },
];

// ─── Routes ───────────────────────────────────────────────────────────────────
const AppRoutes = () => {
  const { loading } = useAuth();

  if (loading) return <Loader />;

  return (
    <Suspense fallback={<Loader />}>
      <Routes>
        {/* Public */}
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/course/:id" element={<CourseDetails />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* Student */}
        <Route
          path="/student"
          element={
            <ProtectedRoute>
              <RoleRoute allowedRoles={['student']}>
                <DashboardLayout sidebarItems={STUDENT_SIDEBAR} />
              </RoleRoute>
            </ProtectedRoute>
          }
        >
          <Route index element={<Navigate to="/student/dashboard" replace />} />
          <Route path="dashboard" element={<StudentDashboard />} />
          <Route path="courses" element={<MyCourses />} />
          <Route path="profile" element={<Profile />} />
          <Route path="quiz/:courseId" element={<QuizPage />} />
          <Route path="chat/:courseId" element={<ChatPage />} />
          <Route path="learn/:courseId" element={<LessonPlayer />} />
          <Route path="learn/:courseId/:lessonId" element={<LessonPlayer />} />
        </Route>

        {/* Instructor */}
        <Route
          path="/instructor"
          element={
            <ProtectedRoute>
              <RoleRoute allowedRoles={['instructor']}>
                <DashboardLayout sidebarItems={INSTRUCTOR_SIDEBAR} />
              </RoleRoute>
            </ProtectedRoute>
          }
        >
          <Route index element={<Navigate to="/instructor/dashboard" replace />} />
          <Route path="dashboard" element={<InstructorDashboard />} />
          <Route path="create-course" element={<CreateCourse />} />
          <Route path="courses" element={<InstructorManageCourses />} />
          <Route path="upload-lesson" element={<UploadLesson />} />
        </Route>

        {/* Admin */}
        <Route
          path="/admin"
          element={
            <ProtectedRoute>
              <RoleRoute allowedRoles={['admin']}>
                <DashboardLayout sidebarItems={ADMIN_SIDEBAR} />
              </RoleRoute>
            </ProtectedRoute>
          }
        >
          <Route index element={<Navigate to="/admin/dashboard" replace />} />
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route path="users" element={<ManageUsers />} />
          <Route path="courses" element={<AdminManageCourses />} />
          <Route path="analytics" element={<Analytics />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
};

export default AppRoutes;
