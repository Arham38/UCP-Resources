package com.expensesplitter.controllers;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * JavaFX Controller for the Search screen.
 * Linked to Search.fxml via fx:controller attribute.
 *
 * Responsibilities:
 *   - Handle button clicks and form submissions
 *   - Validate inputs using InputValidator
 *   - Call DAO and AI methods
 *   - Update UI with results
 *
 * Student : Muhammad Arham | L1F23BSSE0372
 * Package : com.expensesplitter.controllers
 */
public class SearchController implements Initializable {

    /**
     * Called automatically after FXML is loaded.
     * Initialize UI components, load default data here.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // TODO: Initialize Search screen components
    }
}
